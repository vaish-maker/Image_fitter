# IMAGE-FITERING-
This project demonstrates how to apply various image filters using only CSS and HTML. It includes examples of popular filters like grayscale, sepia, blur, brightness, contrast, and more, all implemented with CSS's filter property.
